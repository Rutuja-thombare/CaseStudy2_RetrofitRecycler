package com.example.recyclerretrofit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebViewClient
import kotlinx.android.synthetic.main.activity_details.*

class Details : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
        title = "News Details"

        val string : String ?= intent.getStringExtra("URL")

        myWebView.webViewClient = WebViewClient()   //url loading
        if (string != null) {
            myWebView.loadUrl(string)
        }
        myWebView.settings.setSupportZoom(true)

    }
}