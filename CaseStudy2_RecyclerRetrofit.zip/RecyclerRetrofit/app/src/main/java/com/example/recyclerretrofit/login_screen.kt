package com.example.recyclerretrofit

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.preference.PreferenceManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_login_screen.*


class login_screen : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor
    private lateinit var name: EditText
    private lateinit var password: EditText
    private lateinit var checkBox: CheckBox
    private lateinit var strName: String
    private lateinit var strPassword: String
    private lateinit var strCheckBox: String



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_screen)

        title = "Login Screen"
        name = findViewById(R.id.textName)
        password = findViewById(R.id.textPassword)
        checkBox = findViewById(R.id.checkBox)

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)

        //sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE)
        editor = sharedPreferences.edit()


        checkSharedPreference()

        buttonLogin.setOnClickListener {

            if(checkBox.isChecked){
                editor.putString(getString(R.string.checkbox), "True")
                editor.apply()
                strName = name.text.toString()
                editor.putString(getString(R.string.name), strName).toString()
                editor.commit()
                strPassword = password.text.toString()
                editor.putString(getString(R.string.password), strPassword).toString()
                editor.commit()

                Toast.makeText(this,"Username and password remembered",Toast.LENGTH_SHORT).show()

                var intent = Intent(this,MainActivity::class.java)
                startActivity(intent)
            }
            else  {
                editor.putString(getString(R.string.checkBox), "False")
                editor.commit()
                editor.putString(getString(R.string.name), "")
                editor.commit()
                editor.putString(getString(R.string.password), "")
                editor.commit()

                Toast.makeText(this,"Field cannot be empty",Toast.LENGTH_SHORT).show()


            }

        }


    }

    private fun checkSharedPreference() {
        strCheckBox = sharedPreferences.getString(getString(R.string.checkBox), "False").toString()
        strName = sharedPreferences.getString(getString(R.string.name), "").toString()
        strPassword = sharedPreferences.getString(getString(R.string.password), "").toString()
        name.setText(strName)
        password.setText(strPassword)
        checkBox.isChecked = strCheckBox == "True"
    }
}