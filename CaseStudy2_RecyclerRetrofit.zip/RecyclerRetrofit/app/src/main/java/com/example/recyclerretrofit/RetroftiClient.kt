package com.example.recyclerretrofit

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

const val API_key = "3021ac0cee4642daa2dfca6c16c413f9"
class RetroftiClient {

    //newsapi.org/v2/top-headlines?apiKey=3021ac0cee4642daa2dfca6c16c413f9&country=us&category=business

    interface Api{
        @GET("v2/top-headlines?apiKey=$API_key")
        fun getUser(@Query("country") contry1:String,
                    @Query("category") category1:String): Call<Users>
    }

   /* object Retroclient {
        val newsInstace: Api
        init {
            val retrofit = Retrofit.Builder()
                .baseUrl("http://newsapi.org/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
            newsInstace = retrofit.create(Api::class.java)
        }

    }*/

    companion object{
        var BASE_URL ="http://newsapi.org/"

        fun create(): Api{
            val retrofit = Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .baseUrl(BASE_URL)
                .build()
            return retrofit.create(Api::class.java)
        }
    }
}