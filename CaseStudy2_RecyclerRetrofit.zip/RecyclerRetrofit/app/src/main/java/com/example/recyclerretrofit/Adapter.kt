package com.example.recyclerretrofit

import android.content.Context
import android.content.Intent
import android.telecom.Call
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.single_item.view.*

class Adapter(private val context: Context, val articleList: List<Article>) : RecyclerView.Adapter<Adapter.ArticleViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArticleViewHolder {

        var itemView  = LayoutInflater.from(parent.context).inflate(R.layout.single_item, parent, false)
        return ArticleViewHolder(itemView)

    }

    override fun getItemCount(): Int {
        return articleList.size

    }

    override fun onBindViewHolder(holder:ArticleViewHolder, position: Int) {

        val a = articleList[position]
        holder.Atitle.text = a.title
        Glide.with(context).load(a.urlToImage).into(holder.AurlToImage)
        holder.Adescription.text = a.description

        val intent = Intent(context, Details::class.java)

        holder.itemView.setOnClickListener {
            intent.putExtra("URL", a.url)
            context.startActivity(intent)
        }

    }

    class ArticleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var Atitle = itemView.findViewById<TextView>(R.id.textViewTitle)
        var AurlToImage= itemView.findViewById<ImageView>(R.id.imageView)
        var Adescription= itemView.findViewById<TextView>(R.id.textViewDescription)


    }

}