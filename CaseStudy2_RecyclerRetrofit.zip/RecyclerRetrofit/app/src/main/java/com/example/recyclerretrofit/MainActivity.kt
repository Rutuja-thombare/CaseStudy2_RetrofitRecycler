package com.example.recyclerretrofit

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response



class MainActivity : AppCompatActivity() {

    lateinit var mService : RetroftiClient.Api
    lateinit var layoutManager: LinearLayoutManager
    lateinit var adapter: Adapter



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "News"

        getArticleList()
    }

    private fun getArticleList() {
        val list = RetroftiClient.create().getUser("us","business")
        list.enqueue(object : Callback<Users>{
            override fun onFailure(call: Call<Users>, t: Throwable) {
               Log.e("mytag","error is"+t)
            }

            override fun onResponse(call: Call<Users>, response: Response<Users>) {
                println(response.body()?.totalResults)
                println(response.body()?.article?.size)

                for(i in response.body()?.article!!){
                    println(i)
                }

                showData(response.body()!!.article)
            }

        })
    }

    private fun showData(article: List<Article>) {
        myRecyclerView.apply {
            var myRecyclerView = findViewById<RecyclerView>(R.id.myRecyclerView)as RecyclerView
            myRecyclerView.layoutManager = LinearLayoutManager(this@MainActivity)
            myRecyclerView.adapter = Adapter(context,article)
        }
    }

}








