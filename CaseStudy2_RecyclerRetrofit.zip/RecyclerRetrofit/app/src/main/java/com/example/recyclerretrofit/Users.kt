package com.example.recyclerretrofit

import com.google.gson.annotations.SerializedName

data class Users (var totalResults: Int ,
                       @SerializedName("articles")
                       var article: List<Article>)



data class Article (
    var title : String,
    var description : String,
    var url : String,
    var urlToImage : String
)
